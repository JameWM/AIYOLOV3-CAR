names = ["bicycle","bus","car","motorbike","truck"]
color_dict = {"bicycle": (179, 52, 255),
              "bus": (255, 191, 0),
              "car": (127, 255, 0),
              "motorbike": (0, 140, 255),
              "truck": (0, 215, 255)}