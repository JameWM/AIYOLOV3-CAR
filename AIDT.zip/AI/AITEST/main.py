A = "JK,LK"
B = A.split(",")
print(B)